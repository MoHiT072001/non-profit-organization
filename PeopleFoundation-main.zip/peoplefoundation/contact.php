<?php
	$name = $_POST['name'];
	$visitor_email = $_POST['email'];
	$message = $_POST['message'];
	
	$from = 'wizardsatWork@gmail.com';
	$subject = "Non Profit Organization Submission";
	$body = "User Name: $name.\n".
		"User Email: $visitor_email.\n".
		"User message: $message.\n";
	
	
	$to = "wizardsatwork@gmail.com';
	$headers = "From: $from\r\n";
	$headers .= "Reply-To: $visitor_email\r\n";
	mail($to, $subject,$body,$headers);
	header("Location: Login.html");
?>